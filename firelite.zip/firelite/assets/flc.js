( function () {
	const cfg = window.FLC || {};
	const freeAt = Number( cfg.freeAt ) || 20000;
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-KE' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8243;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const heart = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';
	const waLink = ( text ) => 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( text );
	// Machines sold in several configurations are chosen on the product page.
	const hasOptions = ( p ) => p.type !== 'simple' || p.has_options;

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.flc-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'flc-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		const t = document.createElement( 'div' );
		t.className = 'flc-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3200 );
		setTimeout( () => t.remove(), 3700 );
	}
	document.body.addEventListener( 'wc-blocks_added_to_cart', () => toast( '⚡ Added to your cart' ) );
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( '⚡ Added to your cart' ) );
	// The product page reloads after "Add to cart"; WooCommerce's notice says so too, the toast makes it pop.
	if ( document.querySelector( '.woocommerce-message, .wc-block-components-notice-banner.is-success' ) && /added to your cart/i.test( document.body.textContent ) ) {
		setTimeout( () => toast( '⚡ Added to your cart' ), 300 );
	}

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart (Interactivity API, or wp.data on
	// older WooCommerce); tell whichever is on the page to reload it.
	async function refreshMiniCart( cart ) {
		try {
			const { store } = await import( '@wordpress/interactivity' );
			const wc = store( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
	}
	async function syncBar() {
		try {
			const cart = await getCart();
			renderBar( money( cart.totals.total_items, cart.totals ) );
		} catch ( e ) {}
	}
	document.body.addEventListener( 'wc-blocks_removed_from_cart', syncBar );
	document.body.addEventListener( 'wc-blocks_added_to_cart', () => setTimeout( syncBar, 400 ) );
	// Quantity buttons and remove links inside the mini cart drawer.
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.closest( '.wc-block-mini-cart__drawer button, .wc-block-mini-cart__drawer a' ) && ! e.target.closest( '[data-flc-wa-cart]' ) ) setTimeout( syncBar, 900 );
	} );

	// Adds one product or several at once (one batch request), then updates the mini cart.
	async function addToCart( ids, btn, quiet ) {
		ids = [].concat( ids ).map( Number ).filter( Boolean );
		if ( btn ) btn.disabled = true;
		try {
			if ( ! nonce ) await getCart();
			let cart;
			if ( ids.length === 1 ) {
				const res = await fetch( cfg.store + 'cart/add-item', {
					method: 'POST',
					credentials: 'same-origin',
					headers: { 'Content-Type': 'application/json', Nonce: nonce },
					body: JSON.stringify( { id: ids[ 0 ], quantity: 1 } ),
				} );
				cart = await res.json();
				if ( ! res.ok ) throw new Error( cart.message || 'Could not add' );
			} else {
				const res = await fetch( cfg.store + 'batch', {
					method: 'POST',
					credentials: 'same-origin',
					headers: { 'Content-Type': 'application/json', Nonce: nonce },
					body: JSON.stringify( { requests: ids.map( ( id ) => ( { path: '/wc/store/v1/cart/add-item', method: 'POST', body: { id, quantity: 1 }, headers: { Nonce: nonce } } ) ) } ),
				} );
				const out = await res.json();
				const failed = ( out.responses || [] ).find( ( r ) => r.status >= 400 );
				if ( ! res.ok || failed ) throw new Error( ( failed && failed.body && failed.body.message ) || out.message || 'Could not add' );
				cart = await getCart();
			}
			if ( quiet ) return true;
			await refreshMiniCart( cart );
			// The mini cart opens its drawer on this event; our toast listens too.
			document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true } ) );
			// The drawer can briefly re-show an older copy while it opens; refresh once more after.
			setTimeout( () => refreshMiniCart(), 900 );
			renderBar( money( cart.totals.total_items, cart.totals ) );
			return true;
		} catch ( e ) {
			toast( esc( plain( e.message || 'Could not add to cart. Please try again.' ) ) );
			return false;
		} finally {
			if ( btn ) btn.disabled = false;
		}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-flc-add]' );
		if ( ! b ) return;
		e.preventDefault();
		addToCart( b.dataset.flcAdd.split( ',' ), b );
	} );

	// "Add it all to cart": the extras through the Store API, then the machine through its own form,
	// so its configuration and upgrades come along (the page reloads with the cart updated).
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-flc-bundle]' );
		if ( ! b ) return;
		e.preventDefault();
		const form = document.querySelector( 'form.cart' );
		const main = form && form.querySelector( '.single_add_to_cart_button' );
		if ( ! main ) return;
		if ( main.classList.contains( 'disabled' ) || main.disabled ) {
			toast( 'Choose a configuration first, then add it all.' );
			form.scrollIntoView( { behavior: 'smooth', block: 'center' } );
			return;
		}
		b.textContent = 'Adding everything…';
		if ( await addToCart( b.dataset.flcBundle.split( ',' ), b, true ) ) main.click();
	} );

	/* WhatsApp checkout -------------------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-flc-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab now (inside the click) so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your cart is empty.' );
				return;
			}
			const lines = [ 'Hi Firelite Computers, I\'d like to order:' ];
			cart.items.forEach( ( it ) => {
				// Chosen configuration, RAM / SSD upgrades and add-ons.
				const picks = ( it.variation || [] ).map( ( v ) => plain( v.value ) ).concat( ( it.item_data || [] ).map( ( d ) => plain( d.name || d.key ) + ': ' + plain( d.value ) ) );
				lines.push( '• ' + it.quantity + ' × ' + plain( it.name ) + ( picks.length ? ' (' + picks.join( '; ' ) + ')' : '' ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) ) );
			} );
			( cart.coupons || [] ).forEach( ( c ) => lines.push( 'Promo code: ' + c.code.toUpperCase() ) );
			lines.push( 'Subtotal: ' + fmt( money( cart.totals.total_items, cart.totals ) - money( cart.totals.total_discount, cart.totals ) ) + ' (plus delivery)' );
			lines.push( 'Delivery to: ' );
			const url = waLink( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your cart. Please try again.' );
		}
	} );

	/* Wishlist ---------------------------------------------------------- */
	const KEY = 'flc-wishlist';
	const readWish = () => {
		try {
			return JSON.parse( localStorage.getItem( KEY ) || '[]' ).map( Number ).filter( Boolean );
		} catch ( e ) {
			return [];
		}
	};
	const writeWish = ( ids ) => {
		try {
			localStorage.setItem( KEY, JSON.stringify( ids ) );
		} catch ( e ) {}
	};
	function paintWish() {
		const ids = readWish();
		// Only touch the DOM when something changed: the MutationObserver below calls this.
		$$( '[data-flc-wish]' ).forEach( ( b ) => {
			const on = ids.includes( Number( b.dataset.flcWish ) );
			if ( b.classList.contains( 'is-on' ) === on ) return;
			b.classList.toggle( 'is-on', on );
			b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
		} );
		$$( '[data-flc-wish-count]' ).forEach( ( el ) => {
			if ( el.textContent !== String( ids.length ) ) el.textContent = ids.length;
			el.hidden = ids.length === 0;
		} );
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-flc-wish]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const id = Number( b.dataset.flcWish );
		let ids = readWish();
		const on = ids.includes( id );
		ids = on ? ids.filter( ( x ) => x !== id ) : [ ...ids, id ];
		writeWish( ids );
		paintWish();
		toast( on ? 'Removed from your wishlist' : '♥ Saved to your <a href="' + esc( cfg.home || '/' ) + 'wishlist/">wishlist</a>' );
		if ( b.closest( '[data-flc-wishlist]' ) ) renderWishlist();
	} );

	const buyButton = ( p ) => {
		if ( ! p.is_in_stock ) return '<span class="flc-badge flc-badge--out">Out of stock</span>';
		return hasOptions( p )
			? '<a class="wp-element-button" href="' + esc( p.permalink ) + '">Choose specs</a>'
			: '<button type="button" class="wp-element-button" data-flc-add="' + p.id + '">Add to cart</button>';
	};

	async function renderWishlist() {
		const box = document.querySelector( '[data-flc-wishlist]' );
		if ( ! box ) return;
		const ids = readWish();
		if ( ! ids.length ) {
			box.innerHTML = '<div class="flc-empty"><p>Your wishlist is empty. Tap the ♥ on any product to save it here.</p><a class="wp-element-button" href="' + esc( cfg.shop || '/shop/' ) + '">Browse the shop</a></div>';
			return;
		}
		try {
			const res = await fetch( cfg.store + 'products?include=' + ids.join( ',' ) + '&per_page=50' );
			const items = await res.json();
			box.innerHTML = '<div class="flc-wish-grid">' + items.map( ( p ) => {
				const img = p.images && p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail || p.images[ 0 ].src ) + '" alt="" loading="lazy">' : '';
				return '<article class="flc-wish-card"><a href="' + esc( p.permalink ) + '">' + img + '</a>' +
					'<button type="button" class="flc-heart is-on" data-flc-wish="' + p.id + '" aria-label="Remove from wishlist" aria-pressed="true">' + heart + '</button>' +
					'<h3><a href="' + esc( p.permalink ) + '">' + p.name + '</a></h3><div class="flc-wish-price">' + p.price_html + '</div>' + buyButton( p ) + '</article>';
			} ).join( '' ) + '</div>';
		} catch ( e ) {
			box.innerHTML = '<p>Could not load your wishlist. Please refresh the page.</p>';
		}
	}

	/* Quick view --------------------------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-flc-qv]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const dlg = document.getElementById( 'flc-qv' );
		const body = dlg && dlg.querySelector( '[data-flc-qv-body]' );
		if ( ! body || ! dlg.showModal ) return;
		body.innerHTML = '<p class="flc-small">Loading…</p>';
		dlg.showModal();
		try {
			const p = await ( await fetch( cfg.store + 'products/' + b.dataset.flcQv ) ).json();
			const imgs = ( p.images || [] ).map( ( im, i ) => '<img src="' + esc( im.src ) + '" alt="' + esc( im.alt || plain( p.name ) ) + '"' + ( i ? ' hidden' : '' ) + '>' ).join( '' );
			const thumbs = ( p.images || [] ).length > 1 ? '<div class="flc-qv__thumbs">' + p.images.map( ( im, i ) => '<button type="button" data-flc-qv-img="' + i + '"' + ( i ? '' : ' class="is-on"' ) + '><img src="' + esc( im.thumbnail || im.src ) + '" alt=""></button>' ).join( '' ) + '</div>' : '';
			const cat = p.categories && p.categories[ 0 ] ? '<p class="flc-eyebrow">' + esc( plain( p.categories[ 0 ].name ) ) + '</p>' : '';
			const tags = ( b.dataset.cond ? '<span class="flc-tag flc-tag--inline">' + esc( b.dataset.cond ) + '</span>' : '' ) + ( b.dataset.badge ? '<span class="flc-badge">' + esc( b.dataset.badge ) + '</span>' : '' );
			const more = b.dataset.config || hasOptions( p ) ? 'Choose specs, RAM &amp; SSD upgrades →' : 'Full details &amp; specs →';
			body.innerHTML = '<div class="flc-qv__grid"><div class="flc-qv__media"><div class="flc-qv__main">' + imgs + '</div>' + thumbs + '</div>' +
				'<div class="flc-qv__info">' + cat + '<h2>' + p.name + '</h2>' + ( tags ? '<div class="flc-badges">' + tags + '</div>' : '' ) + '<div class="flc-qv__price">' + p.price_html + '</div>' +
				'<div class="flc-qv__desc">' + ( p.short_description || '' ) + '</div>' +
				'<div class="flc-qv__actions">' + buyButton( p ) +
				'<a class="flc-link" href="' + esc( p.permalink ) + '">' + more + '</a></div></div></div>';
		} catch ( err ) {
			body.innerHTML = '<p>Could not load this product. Please try again.</p>';
		}
	} );
	document.addEventListener( 'click', ( e ) => {
		const t = e.target.closest( '[data-flc-qv-img]' );
		if ( ! t ) return;
		const media = t.closest( '.flc-qv__media' );
		media.querySelectorAll( '.flc-qv__main img' ).forEach( ( im, i ) => ( im.hidden = i !== Number( t.dataset.flcQvImg ) ) );
		media.querySelectorAll( '[data-flc-qv-img]' ).forEach( ( x ) => x.classList.toggle( 'is-on', x === t ) );
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.flc-dialog' ) ) e.target.close();
	} );

	/* Instant search ----------------------------------------------------- */
	function initSearch() {
		$$( '.flc-search input[type="search"]' ).forEach( ( input ) => {
			const form = input.closest( 'form' );
			const list = document.createElement( 'div' );
			list.className = 'flc-suggest';
			list.hidden = true;
			form.style.position = 'relative';
			form.appendChild( list );
			let timer;
			let seq = 0;
			input.setAttribute( 'autocomplete', 'off' );
			input.addEventListener( 'input', () => {
				clearTimeout( timer );
				const q = input.value.trim();
				if ( q.length < 2 ) {
					list.hidden = true;
					return;
				}
				timer = setTimeout( async () => {
					const mine = ++seq;
					try {
						const res = await fetch( cfg.home + '?rest_route=/flc/v1/search&q=' + encodeURIComponent( q ) );
						const items = await res.json();
						if ( mine !== seq ) return;
						list.innerHTML = items.length
							? items.map( ( p ) => '<a href="' + esc( p.permalink ) + '">' + ( p.image ? '<img src="' + esc( p.image ) + '" alt="">' : '' ) + '<span>' + esc( p.name ) + '<small>' + ( p.badge ? esc( p.badge ) + ' · ' : '' ) + p.price_html + '</small></span></a>' ).join( '' ) + '<button type="submit">See all results for “' + esc( q ) + '”</button>'
							: '<p>No products match “' + esc( q ) + '”. <a href="' + esc( waLink( 'Hi Firelite Computers, do you have ' + q + '?' ) ) + '">Ask us on WhatsApp</a></p>';
						list.hidden = false;
					} catch ( e ) {}
				}, 180 );
			} );
			document.addEventListener( 'click', ( e ) => {
				if ( ! form.contains( e.target ) ) list.hidden = true;
			} );
			input.addEventListener( 'keydown', ( e ) => {
				if ( e.key === 'Escape' ) list.hidden = true;
			} );
		} );
	}

	/* Price slider ------------------------------------------------------- */
	function initPrice() {
		$$( '[data-flc-price]' ).forEach( ( form ) => {
			const [ lo, hi ] = $$( 'input[type="range"]', form );
			const out = form.querySelector( 'output' );
			const paint = ( moved ) => {
				// The two handles can't cross.
				if ( Number( lo.value ) > Number( hi.value ) ) {
					if ( moved === lo ) hi.value = lo.value;
					else lo.value = hi.value;
				}
				out.textContent = fmt( lo.value ) + ' – ' + fmt( hi.value );
			};
			lo.addEventListener( 'input', () => paint( lo ) );
			hi.addEventListener( 'input', () => paint( hi ) );
		} );
	}

	/* Configuration options as buttons ----------------------------------- */
	function initSwatches() {
		const jq = window.jQuery;
		if ( ! jq ) return;
		$$( 'form.variations_form table.variations select' ).forEach( ( sel ) => {
			const all = Array.from( sel.options ).filter( ( o ) => o.value ).map( ( o ) => ( { v: o.value, t: o.textContent } ) );
			const wrap = document.createElement( 'div' );
			wrap.className = 'flc-swatches';
			// WooCommerce removes the choices that don't exist with what is already picked.
			const paint = () => {
				const live = new Set( Array.from( sel.options ).filter( ( o ) => o.value && ! o.disabled ).map( ( o ) => o.value ) );
				wrap.innerHTML = all.map( ( o ) => '<button type="button" class="flc-swatch' + ( sel.value === o.v ? ' is-on' : '' ) + '" data-v="' + esc( o.v ) + '"' + ( live.has( o.v ) ? '' : ' disabled' ) + '>' + esc( o.t ) + '</button>' ).join( '' );
			};
			wrap.addEventListener( 'click', ( e ) => {
				const b = e.target.closest( '.flc-swatch' );
				if ( ! b || b.disabled ) return;
				sel.value = sel.value === b.dataset.v ? '' : b.dataset.v;
				jq( sel ).trigger( 'change' );
			} );
			sel.classList.add( 'flc-swatch-select' );
			sel.after( wrap );
			paint();
			jq( sel.form ).on( 'woocommerce_update_variation_values woocommerce_variation_has_changed reset_data', () => setTimeout( paint, 0 ) );
		} );
		// Machines with one obvious configuration start with it picked.
		$$( 'form.variations_form' ).forEach( ( form ) => {
			const sel = form.querySelector( 'table.variations select' );
			if ( sel && ! sel.value && form.querySelectorAll( 'table.variations select' ).length === 1 && sel.options[ 1 ] ) {
				sel.value = sel.options[ 1 ].value;
				jq( sel ).trigger( 'change' );
			}
		} );
	}

	/* Upgrades, add-ons and the live total ------------------------------- */
	function initConfig() {
		const box = document.querySelector( '[data-flc-config]' );
		const form = document.querySelector( 'form.cart' );
		const wa = document.querySelector( '[data-flc-wa-product]' );
		if ( ! form ) return;
		let base = box && box.dataset.base !== '' ? Number( box.dataset.base ) : null;
		let variant = '';
		const summary = () => {
			const parts = variant ? [ variant ] : [];
			$$( '.flc-up input:checked', form ).forEach( ( i ) => {
				if ( Number( i.dataset.fee ) ) parts.push( i.closest( '.flc-opt' ).querySelector( 'strong' ).textContent + ' upgrade' );
			} );
			$$( '.flc-addon input:checked', form ).forEach( ( i ) => parts.push( i.closest( '.flc-addon' ).querySelector( 'span' ).textContent ) );
			return parts;
		};
		const paint = () => {
			const fees = $$( '[data-flc-config] input:checked', form ).reduce( ( s, i ) => s + Number( i.dataset.fee || 0 ), 0 );
			const out = box && box.querySelector( '[data-flc-total]' );
			if ( out ) {
				out.textContent = base === null ? 'Choose a configuration' : fmt( base + fees );
				out.classList.remove( 'is-bump' );
				void out.offsetWidth;
				out.classList.add( 'is-bump' );
			}
			if ( wa ) {
				const parts = summary();
				const price = base === null ? '' : ' – ' + fmt( base + fees );
				wa.href = waLink( 'Hi Firelite Computers, I\'d like the ' + wa.dataset.flcWaProduct + ( parts.length ? ' (' + parts.join( '; ' ) + ')' : '' ) + price + '. Is it available? ' + wa.dataset.flcWaUrl );
			}
		};
		form.addEventListener( 'change', ( e ) => {
			if ( e.target.closest( '[data-flc-config]' ) ) paint();
		} );
		if ( window.jQuery ) {
			window.jQuery( form ).on( 'found_variation', ( e, v ) => {
				base = Number( v.display_price );
				variant = Object.values( v.attributes || {} ).filter( Boolean ).join( ', ' );
				paint();
			} );
			window.jQuery( form ).on( 'reset_data', () => {
				base = null;
				variant = '';
				paint();
			} );
		}
		paint();
	}

	/* Wholesale quote ---------------------------------------------------- */
	document.addEventListener( 'submit', ( e ) => {
		const form = e.target.closest( '[data-flc-wholesale]' );
		if ( ! form ) return;
		e.preventDefault();
		const d = Object.fromEntries( new FormData( form ) );
		const text = [
			'Hi Firelite Computers, I\'d like a wholesale quote.',
			'Name: ' + d.name + ( d.company ? ' (' + d.company + ')' : '' ),
			'Phone: ' + d.phone,
			'Items:',
			d.items.trim(),
			'Delivery to: ' + d.county,
			'Needed: ' + d.when,
		].join( '\n' );
		window.open( waLink( text ), '_blank', 'noopener' );
		toast( '⚡ Opening WhatsApp with your request…' );
	} );

	/* Free-delivery bar and promo codes ---------------------------------- */
	function renderBar( total ) {
		const left = Math.max( 0, freeAt - total );
		const pct = Math.min( 100, Math.round( ( total / freeAt ) * 100 ) );
		const msg = left > 0
			? 'Add <strong>' + fmt( left ) + '</strong> more for <strong>free Nairobi CBD express delivery!</strong>'
			: "<strong>You've unlocked free Nairobi CBD express delivery!</strong>";
		$$( '[data-flc-freebar]' ).forEach( ( el ) => {
			el.innerHTML = msg + '<div class="flc-freebar__track"><div class="flc-freebar__fill" style="width:' + pct + '%"></div></div>';
		} );
	}
	function watchCart() {
		const data = window.wp && window.wp.data;
		if ( ! data || ! data.select( 'wc/store/cart' ) ) return;
		let last = null;
		let codes = null;
		data.subscribe( () => {
			const store = data.select( 'wc/store/cart' );
			const totals = store.getCartTotals();
			if ( totals && totals.total_items !== undefined ) {
				const sub = money( totals.total_items, totals );
				if ( sub !== last ) {
					last = sub;
					renderBar( sub );
				}
			}
			const now = ( store.getCartData().coupons || [] ).map( ( c ) => c.code );
			if ( codes !== null ) now.filter( ( c ) => ! codes.includes( c ) ).forEach( ( c ) => toast( '✓ Promo code <strong>' + esc( c.toUpperCase() ) + '</strong> applied' ) );
			if ( store.hasFinishedResolution && store.hasFinishedResolution( 'getCartData' ) ) codes = now;
		} );
	}

	function init() {
		paintWish();
		renderWishlist();
		initSearch();
		initPrice();
		// Before the swatches: they pick the first configuration, which fires found_variation.
		initConfig();
		initSwatches();
		watchCart();
		// Cards re-render client-side in some blocks; keep hearts in sync.
		new MutationObserver( () => paintWish() ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
