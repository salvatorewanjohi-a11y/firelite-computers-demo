<?php
/**
 * Firelite Computers child theme.
 */

const FLC_FREE_DELIVERY = 20000; // KSh, keep in step with the free Nairobi CBD express delivery shipping method.
const FLC_WHATSAPP      = '254796049477';
const FLC_PHONE         = '0796 049 477';
const FLC_PHONE_2       = '0740 949 022';
const FLC_LOW_STOCK     = 2;
const FLC_FONTS         = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap';
const FLC_FILTERS       = [ 'cpu' => 'Processor', 'ram' => 'RAM', 'storage' => 'Storage', 'screen' => 'Screen size', 'condition' => 'Condition' ];
const FLC_ADDRESS       = 'Central Building, 1st Floor, Shop No. 10, Moi Avenue';
const FLC_HOURS         = 'Monday – Saturday: 8:00 AM – 7:30 PM (closed Sundays)';

// Upgrade prices. PLACEHOLDER: to confirm with Firelite. The cost of an upgrade is the price of the
// size chosen minus the price of the size the machine ships with (8GB → 16GB = 5,500 − 2,000).
const FLC_RAM_PRICE = [ 4 => 0, 8 => 2000, 16 => 5500, 24 => 8500, 32 => 11500 ];
const FLC_SSD_PRICE = [ 256 => 0, 512 => 3500, 1024 => 8500 ];

// Optional add-ons on the product page: [label, KSh, the kinds of product that offer it]. PLACEHOLDER prices.
const FLC_ADDONS = [
	'setup' => [ 'Software setup: Windows Pro & Microsoft Office installed, plus your apps', 1000, [ 'laptop', 'desktop' ] ],
	'bag'   => [ 'Laptop bag & wireless mouse combo', 1500, [ 'laptop' ] ],
];

// "Shop by need": attribute term slug => [title, line, icon, product whose photo shows on the tile].
const FLC_USES = [
	'business-corporate'     => [ 'Business & Corporate', 'EliteBooks, ThinkPads & office PCs', '💼', 'hp-elitebook-840-g6' ],
	'university-students'    => [ 'University & Students', 'Reliable laptops on a student budget', '🎓', 'hp-elitebook-x360-1030-g4' ],
	'graphic-design-editing' => [ 'Graphic Design & Editing', 'ZBooks, MacBook Pro & dedicated GPUs', '🎨', 'apple-macbook-pro-16-a2141' ],
	'everyday-computing'     => [ 'Everyday Computing', 'Boxed HP laptops & all-in-ones', '🏠', 'hp-15-core-i7-boxed' ],
	'gaming'                 => [ 'Gaming', 'Omen, Victus & 165Hz monitors', '🎮', 'hp-victus-16-rtx-4050' ],
	'ups-power-backup'       => [ 'UPS & Power Backup', 'APC & Cursor UPS for power cuts', '⚡', 'apc-easy-ups-1kva' ],
];
const FLC_BUDGETS = [ [ 'Under 20K', 0, 20000 ], [ '20K – 35K', 20000, 35000 ], [ '35K – 60K', 35000, 60000 ], [ '60K – 100K', 60000, 100000 ], [ '100K +', 100000, 0 ] ];

const FLC_WA_ICON = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'flc-fonts', FLC_FONTS, [], null );
	wp_enqueue_style( 'flc', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'flc', $uri . '/assets/flc.js', [], filemtime( $dir . '/assets/flc.js' ), true );
	wp_localize_script( 'flc', 'FLC', [
		'freeAt' => FLC_FREE_DELIVERY,
		'store'  => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'   => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'home'   => esc_url_raw( home_url( '/' ) ),
		'wa'     => FLC_WHATSAPP,
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'flc-fonts', FLC_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

function flc_wa_link( $text = '' ) {
	return 'https://wa.me/' . FLC_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}
function flc_ksh( $n ) {
	return 'KSh ' . number_format( (float) $n );
}
function flc_gb( $n ) {
	return $n >= 1024 ? ( $n / 1024 ) . 'TB' : $n . 'GB';
}

/**
 * Specs as label => value pairs, from the "Label: value" lines staff type on the product screen.
 */
function flc_specs( $product_id ) {
	$out = [];
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_flc_specs', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] !== '' ) {
			$out[ $parts[0] ] = $parts[1];
		}
	}
	return $out;
}

// laptop, desktop, monitor, ups, printer or acc (staff pick it on the product screen).
function flc_kind( $product_id ) {
	return (string) get_post_meta( $product_id, '_flc_kind', true );
}

// Upgrade steps for RAM or SSD, e.g. [8, 16, 32]; the first is what the machine ships with.
function flc_steps( $product_id, $what ) {
	$table = $what === 'ram' ? FLC_RAM_PRICE : FLC_SSD_PRICE;
	$steps = array_map( 'intval', array_filter( explode( ',', (string) get_post_meta( $product_id, "_flc_{$what}_steps", true ) ) ) );
	$steps = array_values( array_filter( $steps, fn( $s ) => isset( $table[ $s ] ) ) );
	return count( $steps ) > 1 ? $steps : [];
}
function flc_step_fee( $what, $from, $to ) {
	$table = $what === 'ram' ? FLC_RAM_PRICE : FLC_SSD_PRICE;
	return max( 0, $table[ $to ] - $table[ $from ] );
}
function flc_addons_for( $product_id ) {
	$kind = flc_kind( $product_id );
	return array_filter( FLC_ADDONS, fn( $a ) => in_array( $kind, $a[2], true ) );
}

// Condition tag: new, exuk or mixed (a product sold both ways).
function flc_condition_label( $product_id ) {
	return [ 'new' => 'Brand new', 'exuk' => 'Ex-UK', 'mixed' => 'Ex-UK & boxed' ][ get_post_meta( $product_id, '_flc_cond', true ) ] ?? '';
}

/* -------------------------------------------------------------------------
 * Product page
 * ---------------------------------------------------------------------- */

// Condition and key specs above the add-to-cart button.
add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$cond = flc_condition_label( $product->get_id() );
	if ( $cond ) {
		echo '<p class="flc-cond flc-cond--' . esc_attr( get_post_meta( $product->get_id(), '_flc_cond', true ) ) . '">' . esc_html( $cond ) . '<span>' . ( $cond === 'Brand new' ? 'Sealed in its box' : 'Tested in our shop · test it yourself before you pay' ) . '</span></p>';
	}
	$specs = array_slice( flc_specs( $product->get_id() ), 0, 4, true );
	if ( ! $specs ) {
		return;
	}
	echo '<ul class="flc-keyspecs">';
	foreach ( $specs as $k => $v ) {
		echo '<li><span>' . esc_html( $k ) . '</span><strong>' . esc_html( preg_replace( '/ \(choose above\)$/', '', $v ) ) . '</strong></li>';
	}
	echo '</ul>';
} );

// RAM and SSD upgrades, add-ons and the running total, above the add-to-cart button.
add_action( 'woocommerce_before_add_to_cart_button', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$id     = $product->get_id();
	$ram    = flc_steps( $id, 'ram' );
	$ssd    = flc_steps( $id, 'ssd' );
	$addons = flc_addons_for( $id );
	if ( ! $ram && ! $ssd && ! $addons ) {
		return;
	}
	echo '<div class="flc-config" data-flc-config data-base="' . esc_attr( $product->is_type( 'variable' ) ? '' : (float) $product->get_price() ) . '">';
	foreach ( [ 'ram' => [ $ram, 'Memory (RAM)', '' ], 'ssd' => [ $ssd, 'Storage (SSD)', ' SSD' ] ] as $what => [ $steps, $legend, $suffix ] ) {
		if ( ! $steps ) {
			continue;
		}
		echo '<fieldset class="flc-up"><legend>' . esc_html( $legend ) . ' <em>upgrade</em></legend><div class="flc-up__opts">';
		foreach ( $steps as $n => $size ) {
			$fee = flc_step_fee( $what, $steps[0], $size );
			printf(
				'<label class="flc-opt"><input type="radio" name="flc_%1$s" value="%2$d" data-fee="%3$d"%4$s><span><strong>%5$s</strong><em>%6$s</em></span></label>',
				esc_attr( $what ),
				$size,
				$fee,
				$n ? '' : ' checked',
				esc_html( flc_gb( $size ) . $suffix ),
				$n ? '+ ' . esc_html( flc_ksh( $fee ) ) : 'As listed'
			);
		}
		echo '</div></fieldset>';
	}
	if ( $addons ) {
		echo '<fieldset class="flc-addons"><legend>Add-ons</legend>';
		foreach ( $addons as $key => [ $label, $fee ] ) {
			printf( '<label class="flc-addon"><input type="checkbox" name="flc_addon[]" value="%1$s" data-fee="%2$d"><span>%3$s</span><em>+ %4$s</em></label>', esc_attr( $key ), $fee, esc_html( $label ), esc_html( flc_ksh( $fee ) ) );
		}
		echo '</fieldset>';
	}
	echo '<p class="flc-total">Your machine <strong data-flc-total>' . ( $product->is_type( 'variable' ) ? 'Choose a configuration' : esc_html( flc_ksh( $product->get_price() ) ) ) . '</strong></p>';
	if ( $ram || $ssd ) {
		echo '<p class="flc-small flc-config__note">Upgrades are genuine parts, fitted and tested before collection or delivery.</p>';
	}
	echo '</div>';
} );

// What the customer chose, checked against what this product offers.
function flc_chosen_config( $product_id ) {
	$out = [];
	foreach ( [ 'ram', 'ssd' ] as $what ) {
		$steps = flc_steps( $product_id, $what );
		$to    = (int) ( $_POST[ "flc_$what" ] ?? 0 );
		if ( $steps && $to !== $steps[0] && in_array( $to, $steps, true ) ) {
			$out[ "flc_$what" ] = [ 'to' => $to, 'fee' => flc_step_fee( $what, $steps[0], $to ) ];
		}
	}
	$offered = flc_addons_for( $product_id );
	foreach ( array_map( 'sanitize_key', (array) ( $_POST['flc_addon'] ?? [] ) ) as $key ) {
		if ( isset( $offered[ $key ] ) ) {
			$out['flc_addons'][ $key ] = $offered[ $key ][1];
		}
	}
	return $out;
}
add_filter( 'woocommerce_add_cart_item_data', function ( $data, $product_id ) {
	return array_merge( $data, flc_chosen_config( $product_id ) );
}, 10, 2 );

function flc_item_fees( $item ) {
	return (float) ( $item['flc_ram']['fee'] ?? 0 ) + (float) ( $item['flc_ssd']['fee'] ?? 0 ) + array_sum( $item['flc_addons'] ?? [] );
}
add_action( 'woocommerce_before_calculate_totals', function ( $cart ) {
	foreach ( $cart->get_cart() as $item ) {
		$fees = flc_item_fees( $item );
		if ( ! $fees ) {
			continue;
		}
		// Start from the catalogue price each time: this hook can run more than once per request.
		$base = wc_get_product( $item['variation_id'] ?: $item['product_id'] );
		if ( $base ) {
			$item['data']->set_price( (float) $base->get_price() + $fees );
		}
	}
} );

// The chosen upgrades as label => value rows (cart, checkout, order, WhatsApp).
function flc_config_rows( $item ) {
	$rows = [];
	if ( ! empty( $item['flc_ram'] ) ) {
		$rows['RAM upgrade'] = flc_gb( $item['flc_ram']['to'] ) . ' (+ ' . flc_ksh( $item['flc_ram']['fee'] ) . ')';
	}
	if ( ! empty( $item['flc_ssd'] ) ) {
		$rows['SSD upgrade'] = flc_gb( $item['flc_ssd']['to'] ) . ' SSD (+ ' . flc_ksh( $item['flc_ssd']['fee'] ) . ')';
	}
	$n = 0;
	foreach ( $item['flc_addons'] ?? [] as $key => $fee ) {
		if ( isset( FLC_ADDONS[ $key ] ) ) {
			$rows[ count( $item['flc_addons'] ) > 1 ? 'Add-on ' . ( ++$n ) : 'Add-on' ] = FLC_ADDONS[ $key ][0] . ' (+ ' . flc_ksh( $fee ) . ')';
		}
	}
	return $rows;
}
add_filter( 'woocommerce_get_item_data', function ( $rows, $item ) {
	foreach ( flc_config_rows( $item ) as $k => $v ) {
		$rows[] = [ 'key' => $k, 'value' => $v ];
	}
	return $rows;
}, 10, 2 );
add_action( 'woocommerce_checkout_create_order_line_item', function ( $line, $key, $values ) {
	foreach ( flc_config_rows( $values ) as $k => $v ) {
		$line->add_meta_data( $k, $v );
	}
}, 10, 3 );

// Order on WhatsApp, guarantees and "complete your setup" under the add-to-cart button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$price = $product->is_type( 'variable' ) ? 'from ' . flc_ksh( $product->get_variation_price( 'min' ) ) : flc_ksh( $product->get_price() );
	$msg   = 'Hi Firelite Computers, is the ' . $product->get_name() . ' (' . $price . ') available? ' . $product->get_permalink();
	echo '<a class="flc-wa-order" data-flc-wa-product="' . esc_attr( $product->get_name() ) . '" data-flc-wa-url="' . esc_url( $product->get_permalink() ) . '" href="' . esc_url( flc_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . FLC_WA_ICON . 'Order this on WhatsApp</a>';

	echo '<div class="flc-guarantee"><div><span aria-hidden="true">✓</span><p><strong>Tested &amp; certified</strong>Every Ex-UK machine is checked in our shop before sale. Switch it on and test it yourself at Moi Avenue before you pay.</p></div><div><span aria-hidden="true">🛡</span><p><strong>Warranty on every machine</strong>The warranty period is written on your receipt. Brand-new machines carry the manufacturer\'s warranty.</p></div><div><span aria-hidden="true">⚡</span><p><strong>Same-day delivery in Nairobi</strong>Pay by M-Pesa or cash on delivery, or courier to any county.</p></div></div>';

	$ids   = array_slice( $product->get_upsell_ids(), 0, 3 );
	$items = array_filter( array_map( 'wc_get_product', $ids ), fn( $p ) => $p && $p->is_visible() );
	if ( ! $items ) {
		return;
	}
	$simple = array_filter( $items, fn( $p ) => $p->is_in_stock() && $p->is_type( 'simple' ) );
	echo '<div class="flc-set"><p class="flc-set__title">Complete your setup</p>';
	foreach ( $items as $p ) {
		printf(
			'<div class="flc-set__item"><a href="%s">%s</a><span><a href="%1$s"><strong>%s</strong></a>%s</span>%s</div>',
			esc_url( $p->get_permalink() ),
			$p->get_image( 'thumbnail' ),
			esc_html( $p->get_name() ),
			$p->get_price_html(),
			$p->is_in_stock() && $p->is_type( 'simple' ) ? '<button type="button" class="flc-set__add" data-flc-add="' . (int) $p->get_id() . '" aria-label="Add ' . esc_attr( $p->get_name() ) . ' to cart">+ Add</button>' : ''
		);
	}
	// The machine goes in through its own form (so its upgrades come along), the extras through the Store API.
	if ( $product->is_in_stock() && $simple ) {
		echo '<button type="button" class="flc-set__all" data-flc-bundle="' . esc_attr( implode( ',', array_map( fn( $p ) => $p->get_id(), $simple ) ) ) . '" data-extras="' . esc_attr( array_sum( array_map( fn( $p ) => (float) $p->get_price(), $simple ) ) ) . '">Add it all to cart: this ' . ( flc_kind( $product->get_id() ) === 'laptop' ? 'laptop' : 'item' ) . ' + ' . count( $simple ) . ' extras</button>';
	}
	echo '</div>';
} );

// The upsells already show as "Complete your setup" next to the button.
add_action( 'init', function () {
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
} );

// Specs, warranty & testing and delivery tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) {
		return $tabs;
	}
	$specs = flc_specs( $product->get_id() );
	if ( $specs ) {
		$tabs['flc_specs'] = [
			'title'    => 'Detailed specifications',
			'priority' => 5,
			'callback' => function () use ( $specs ) {
				echo '<table class="flc-spec-table"><tbody>';
				foreach ( $specs as $k => $v ) {
					echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
				}
				echo '</tbody></table>';
			},
		];
	}
	$tabs['flc_warranty'] = [
		'title'    => 'Warranty & testing',
		'priority' => 35,
		'callback' => function () {
			echo '<ul><li><strong>Tested before sale:</strong> every Ex-UK machine is checked in our shop: screen, keyboard and touchpad, ports, Wi-Fi, webcam, speakers, charging and battery.</li><li><strong>Test it yourself:</strong> collect at Central Building, Moi Avenue, switch it on and try it before you pay.</li><li><strong>Brand-new machines:</strong> sealed in the box, with the manufacturer\'s warranty (for example 1 year on the HP Spectre x360 14).</li><li><strong>Ex-UK machines:</strong> covered by our shop warranty. The period for your machine is written on your receipt; ask us before you buy.</li><li><strong>Upgrades:</strong> RAM and SSD upgrades are genuine parts, fitted and tested in our shop.</li><li><strong>Not covered:</strong> physical or liquid damage, and repairs done elsewhere.</li></ul>';
		},
	];
	$tabs['flc_delivery'] = [
		'title'    => 'Delivery & pickup',
		'priority' => 40,
		'callback' => function () {
			echo '<ul><li><strong>Nairobi:</strong> express same-day dispatch, free on orders over ' . esc_html( flc_ksh( FLC_FREE_DELIVERY ) ) . '. Pay by M-Pesa or cash on delivery.</li><li><strong>Upcountry:</strong> parcel courier to any county. We confirm the courier, charge and dispatch time with you before it leaves.</li><li><strong>In-store pickup &amp; testing:</strong> free at ' . esc_html( FLC_ADDRESS ) . ', opposite Sidian Bank, next to Digital Shopping Mall.</li><li><strong>Hours:</strong> ' . esc_html( FLC_HOURS ) . '.</li></ul>';
		},
	];
	if ( isset( $tabs['description'] ) ) {
		$tabs['description']['priority'] = 1;
	}
	if ( isset( $tabs['reviews'] ) ) {
		$tabs['reviews']['title'] = str_replace( 'Reviews', 'Verified customer reviews', $tabs['reviews']['title'] );
	}
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Product cards
 * ---------------------------------------------------------------------- */

function flc_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

const FLC_HEART = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';

// Hover image (first gallery photo), condition tag, wishlist heart and quick view on product images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = flc_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'flc-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$cond   = flc_condition_label( $product->get_id() );
	$config = flc_steps( $product->get_id(), 'ram' ) || flc_steps( $product->get_id(), 'ssd' );
	$extra  = $cond ? '<span class="flc-tag flc-tag--' . esc_attr( get_post_meta( $product->get_id(), '_flc_cond', true ) ) . '">' . esc_html( $cond ) . '</span>' : '';
	$extra .= sprintf(
		'<button type="button" class="flc-heart" data-flc-wish="%1$d" aria-label="Save %2$s to wishlist" aria-pressed="false">%3$s</button><button type="button" class="flc-qv-btn" data-flc-qv="%1$d" data-cond="%4$s" data-badge="%5$s" data-config="%6$s" aria-label="Quick view of %2$s">Quick view</button>',
		$product->get_id(),
		esc_attr( $product->get_name() ),
		FLC_HEART,
		esc_attr( $cond ),
		esc_attr( get_post_meta( $product->get_id(), '_flc_spec', true ) ),
		$config ? '1' : ''
	);
	$pos = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $extra . '</div>', $pos, 6 );
}, 10, 3 );

// Machines sold in several configurations show their lowest price, not a range.
add_filter( 'woocommerce_variable_price_html', function ( $html, $product ) {
	$min = $product->get_variation_price( 'min', true );
	return $min === $product->get_variation_price( 'max', true ) ? $html : '<span class="flc-from">From</span> ' . wc_price( $min );
}, 10, 2 );

// "Select options" reads better as "Choose specs" for configurable machines.
add_filter( 'woocommerce_product_add_to_cart_text', function ( $text, $product ) {
	return $product->is_type( 'variable' ) && $product->is_purchasable() ? 'Choose specs' : $text;
}, 10, 2 );

// Spec badge and stock above the price.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = flc_card_product( $instance );
	if ( ! $product ) {
		return $content;
	}
	$before = '';
	$spec = get_post_meta( $product->get_id(), '_flc_spec', true );
	if ( $spec ) {
		$before .= '<span class="flc-badge">' . esc_html( $spec ) . '</span>';
	}
	if ( ! $product->is_in_stock() ) {
		$before .= '<span class="flc-badge flc-badge--out">Out of stock</span>';
	} elseif ( $product->managing_stock() && (int) $product->get_stock_quantity() <= FLC_LOW_STOCK ) {
		$before .= '<span class="flc-badge flc-badge--low">Only ' . (int) $product->get_stock_quantity() . ' left</span>';
	}
	return ( $before ? '<div class="flc-badges">' . $before . '</div>' : '' ) . $content;
}, 10, 3 );

// Sale badge shows the saving, e.g. "−12%".
add_filter( 'render_block_woocommerce/product-sale-badge', function ( $content, $block, $instance ) {
	$product = flc_card_product( $instance );
	if ( ! $product || ! $product->is_on_sale() ) {
		return $content;
	}
	if ( $product->is_type( 'variable' ) ) {
		$pct = 0;
		foreach ( $product->get_children() as $child ) {
			$v   = wc_get_product( $child );
			$reg = $v ? (float) $v->get_regular_price() : 0;
			$pct = max( $pct, $reg > 0 && $v->is_on_sale() ? round( ( $reg - (float) $v->get_sale_price() ) / $reg * 100 ) : 0 );
		}
		$label = $pct ? 'Up to −' . $pct . '%' : '';
	} else {
		$reg   = (float) $product->get_regular_price();
		$sale  = (float) $product->get_sale_price();
		$label = $reg > 0 && $sale > 0 ? '−' . round( ( $reg - $sale ) / $reg * 100 ) . '%' : '';
	}
	return $label ? preg_replace( '#>\s*Sale\s*<#', '>' . $label . '<', $content, 1 ) : $content;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page and shop sections
 * ---------------------------------------------------------------------- */

function flc_categories() {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

// "Shop by need": one tile per use case, with a photo of a product for it.
add_shortcode( 'flc_needs', function () {
	$tax = wc_attribute_taxonomy_name( 'use' );
	$h   = '<div class="flc-needs">';
	foreach ( FLC_USES as $slug => [ $title, $line, $icon, $pick ] ) {
		$term = get_term_by( 'slug', $slug, $tax );
		if ( ! $term || ! $term->count ) {
			continue;
		}
		$post  = get_page_by_path( $pick, OBJECT, 'product' );
		$first = $post ? [ wc_get_product( $post ) ] : wc_get_products( [ 'limit' => 1, 'status' => 'publish', 'orderby' => 'menu_order', 'order' => 'ASC', 'tax_query' => [ [ 'taxonomy' => $tax, 'field' => 'slug', 'terms' => $slug ] ] ] );
		$img   = $first ? $first[0]->get_image( 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) : '';
		$link  = $slug === 'ups-power-backup' ? get_term_link( 'ups-power', 'product_cat' ) : add_query_arg( 'filter_use', $slug, wc_get_page_permalink( 'shop' ) );
		$h    .= sprintf(
			'<a class="flc-need" href="%s"><span class="flc-need__img">%s<i aria-hidden="true">%s</i></span><span class="flc-need__txt"><strong>%s</strong><em>%s</em><b>%s →</b></span></a>',
			esc_url( is_wp_error( $link ) ? wc_get_page_permalink( 'shop' ) : $link ),
			$img,
			$icon,
			esc_html( $title ),
			esc_html( $line ),
			esc_html( sprintf( _n( '%d product', '%d products', $term->count ), $term->count ) )
		);
	}
	return $h . '</div>';
} );

// A row of product cards from one category, e.g. [flc_collection cat="desktop-pcs" limit="10"].
// Built as a Product Collection block at render time, because the block needs the category's term id.
add_shortcode( 'flc_collection', function ( $atts ) {
	$atts = shortcode_atts( [ 'cat' => '', 'limit' => 10, 'columns' => 5 ], $atts );
	$term = get_term_by( 'slug', $atts['cat'], 'product_cat' );
	if ( ! $term ) {
		return '';
	}
	static $qid = 40;
	$query = [
		'perPage' => (int) $atts['limit'], 'pages' => 1, 'offset' => 0, 'postType' => 'product', 'order' => 'asc', 'orderBy' => 'menu_order',
		'search' => '', 'exclude' => [], 'inherit' => false, 'taxQuery' => [ 'product_cat' => [ $term->term_id ] ], 'isProductCollectionBlock' => true,
		'featured' => false, 'woocommerceOnSale' => false, 'woocommerceStockStatus' => [ 'instock', 'outofstock', 'onbackorder' ], 'woocommerceAttributes' => [], 'woocommerceHandPickedProducts' => [],
	];
	$attrs = [ 'queryId' => $qid++, 'query' => $query, 'tagName' => 'div', 'displayLayout' => [ 'type' => 'flex', 'columns' => (int) $atts['columns'], 'shrinkColumns' => true ], 'dimensions' => [ 'widthType' => 'fill' ], 'queryContextIncludes' => [ 'collection' ] ];
	return do_blocks( '<!-- wp:woocommerce/product-collection ' . wp_json_encode( $attrs ) . ' --><div class="wp-block-woocommerce-product-collection">' . FLC_CARD . '</div><!-- /wp:woocommerce/product-collection -->' );
} );

// The product card used by the shortcode grids (the templates carry the same blocks).
const FLC_CARD = '<!-- wp:woocommerce/product-template -->
<!-- wp:woocommerce/product-image {"showSaleBadge":false,"isDescendentOfQueryLoop":true,"aspectRatio":"1","scale":"cover"} -->
<!-- wp:woocommerce/product-sale-badge {"isDescendentOfQueryLoop":true,"align":"right"} /-->
<!-- /wp:woocommerce/product-image -->
<!-- wp:post-title {"level":3,"isLink":true,"style":{"spacing":{"margin":{"bottom":"0.2rem","top":"0.7rem"}},"typography":{"fontSize":"0.95rem","lineHeight":"1.3","fontWeight":"600"}},"__woocommerceNamespace":"woocommerce/product-collection/product-title"} /-->
<!-- wp:woocommerce/product-rating {"isDescendentOfQueryLoop":true} /-->
<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true,"fontSize":"medium"} /-->
<!-- wp:woocommerce/product-button {"isDescendentOfQueryLoop":true,"fontSize":"small"} /-->
<!-- /wp:woocommerce/product-template -->';

// Brands, the ones with the most products first.
function flc_brands( $limit = 0 ) {
	if ( ! taxonomy_exists( 'product_brand' ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => 'product_brand', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => $limit ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

// Popular ranges, each a product search the shop already answers.
const FLC_RANGES = [ [ 'HP EliteBook', 'elitebook' ], [ 'HP ProBook', 'probook' ], [ 'HP ZBook', 'zbook' ], [ 'Lenovo ThinkPad', 'thinkpad' ], [ 'Dell Latitude & Inspiron', 'dell' ], [ 'Apple MacBook', 'macbook' ], [ 'HP Omen & Victus', 'omen victus' ], [ 'APC & Cursor UPS', 'ups' ] ];
add_shortcode( 'flc_brands', function () {
	$h = '<div class="flc-brands"><p class="flc-brands__label">Popular ranges</p><div class="flc-brands__list">';
	foreach ( FLC_RANGES as [ $label, $q ] ) {
		$h .= '<a href="' . esc_url( add_query_arg( [ 's' => $q, 'post_type' => 'product' ], home_url( '/' ) ) ) . '">' . esc_html( $label ) . '</a>';
	}
	return $h . '<a href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '" class="flc-brands__all">All products →</a></div></div>';
} );

// Product search also looks in the specs and configurations, so "i7", "16GB" or "touch" find
// machines whose title doesn't say it. "omen victus" finds either word (the ranges bar uses it).
add_filter( 'posts_search', function ( $search, $q ) {
	global $wpdb;
	$s = trim( (string) $q->get( 's' ) );
	if ( $s === '' || ! in_array( 'product', (array) $q->get( 'post_type' ), true ) ) {
		return $search;
	}
	$clause = function ( $word ) use ( $wpdb ) {
		$like = '%' . $wpdb->esc_like( $word ) . '%';
		return $wpdb->prepare(
			"({$wpdb->posts}.post_title LIKE %s OR {$wpdb->posts}.post_excerpt LIKE %s OR {$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key IN ('_flc_specs', '_flc_spec', '_product_attributes') AND meta_value LIKE %s))",
			$like, $like, $like
		);
	};
	$words = array_filter( preg_split( '/\s+/', $s ) );
	if ( strtolower( $s ) === 'omen victus' ) {
		return ' AND (' . implode( ' OR ', array_map( $clause, $words ) ) . ') ';
	}
	return ' AND ' . implode( ' AND ', array_map( $clause, $words ) ) . ' ';
}, 10, 2 );

// Instant search in the header: the same search as the results page, as a short JSON list.
add_action( 'rest_api_init', function () {
	register_rest_route( 'flc/v1', '/search', [
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			$q = new WP_Query( [ 'post_type' => 'product', 'post_status' => 'publish', 's' => sanitize_text_field( $req['q'] ), 'posts_per_page' => 6, 'no_found_rows' => true ] );
			return array_map( function ( $post ) {
				$p = wc_get_product( $post );
				return [ 'name' => $p->get_name(), 'permalink' => $p->get_permalink(), 'image' => wp_get_attachment_image_url( $p->get_image_id(), 'thumbnail' ), 'price_html' => $p->get_price_html(), 'badge' => get_post_meta( $p->get_id(), '_flc_spec', true ) ];
			}, $q->posts );
		},
	] );
} );

// Sizes sort by number, not by alphabet: 8GB before 16GB, 512GB before 1TB.
function flc_size_value( $name ) {
	return (float) $name * ( stripos( $name, 'TB' ) !== false ? 1024 : 1 );
}
function flc_term_sort( $key, $terms ) {
	usort( $terms, in_array( $key, [ 'ram', 'storage', 'screen' ], true ) ? fn( $a, $b ) => flc_size_value( $a->name ) <=> flc_size_value( $b->name ) : fn( $a, $b ) => strnatcasecmp( $a->name, $b->name ) );
	return $terms;
}

// The page being filtered, and the filter choices already in its address.
function flc_filter_state() {
	$current = get_queried_object();
	$base    = $current instanceof WP_Term ? get_term_link( $current ) : wc_get_page_permalink( 'shop' );
	$keep    = [];
	foreach ( array_merge( [ 'min_price', 'max_price', 'instock', 'orderby', 's', 'post_type', 'filter_use' ], array_map( fn( $k ) => "filter_$k", array_keys( FLC_FILTERS ) ) ) as $key ) {
		if ( isset( $_GET[ $key ] ) && $_GET[ $key ] !== '' ) {
			$keep[ $key ] = sanitize_text_field( wp_unslash( $_GET[ $key ] ) );
		}
	}
	return [ $current, is_wp_error( $base ) ? wc_get_page_permalink( 'shop' ) : $base, $keep ];
}

// Category, need and budget chips, then price, processor, RAM, storage, screen, condition and brand,
// above shop, category, brand and search results.
add_shortcode( 'flc_filters', function () {
	global $wpdb;
	[ $current, $base, $keep ] = flc_filter_state();
	$cur_id = $current instanceof WP_Term ? $current->term_id : 0;
	$link   = fn( $args ) => esc_url( add_query_arg( $args, $base ) );

	$h = '<nav class="flc-filters" aria-label="Filter products"><div class="flc-filters__row flc-filters__row--cats">';
	$h .= '<a class="flc-chip' . ( is_shop() && ! is_search() ? ' is-on' : '' ) . '" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">All</a>';
	foreach ( flc_categories() as $t ) {
		$h .= sprintf( '<a class="flc-chip%s" href="%s">%s <em>%d</em></a>', $t->term_id === $cur_id ? ' is-on' : '', esc_url( get_term_link( $t ) ), esc_html( $t->name ), (int) $t->count );
	}
	$h .= '</div>';

	// Products on this page before any filter, to offer only the needs, prices and specs that exist here.
	$args = [ 'post_type' => 'product', 'post_status' => 'publish', 'fields' => 'ids', 'posts_per_page' => 500, 'no_found_rows' => true ];
	if ( $current instanceof WP_Term ) {
		$args['tax_query'] = [ [ 'taxonomy' => $current->taxonomy, 'terms' => [ $current->term_id ] ] ];
	}
	$ids = get_posts( $args );

	// Use cases.
	$uses = $ids ? wp_get_object_terms( $ids, wc_attribute_taxonomy_name( 'use' ) ) : [];
	if ( ! is_wp_error( $uses ) && count( $uses ) > 1 ) {
		$have   = wp_list_pluck( $uses, 'slug' );
		$chosen = $keep['filter_use'] ?? '';
		$h     .= '<div class="flc-filters__row"><span class="flc-refine__label">Best for</span>';
		foreach ( FLC_USES as $slug => [ $title, , $icon ] ) {
			if ( ! in_array( $slug, $have, true ) ) {
				continue;
			}
			$on   = $chosen === $slug;
			$args = $on ? array_diff_key( $keep, [ 'filter_use' => 1 ] ) : array_merge( $keep, [ 'filter_use' => $slug ] );
			$h   .= sprintf( '<a class="flc-chip flc-chip--sm%s" href="%s" rel="nofollow">%s %s</a>', $on ? ' is-on' : '', $link( $args ), $icon, esc_html( $title ) );
		}
		$h .= '</div>';
	}

	// Budget, plus the in-stock switch.
	$h .= '<div class="flc-filters__row"><span class="flc-refine__label">Budget</span>';
	foreach ( FLC_BUDGETS as [ $label, $min, $max ] ) {
		$on   = ( isset( $keep['min_price'] ) || isset( $keep['max_price'] ) ) && (int) ( $keep['min_price'] ?? 0 ) === $min && (int) ( $keep['max_price'] ?? 0 ) === $max;
		$args = array_diff_key( $keep, [ 'min_price' => 1, 'max_price' => 1 ] );
		if ( ! $on ) {
			$args = array_merge( $args, array_filter( [ 'min_price' => $min, 'max_price' => $max ] ) );
		}
		$h .= sprintf( '<a class="flc-chip flc-chip--sm%s" href="%s" rel="nofollow">%s</a>', $on ? ' is-on' : '', $link( $args ), esc_html( $label ) );
	}
	$stock_on = ! empty( $keep['instock'] );
	$h       .= sprintf( '<a class="flc-switch%s" href="%s" rel="nofollow" role="switch" aria-checked="%s"><span></span>In stock only</a>', $stock_on ? ' is-on' : '', $link( $stock_on ? array_diff_key( $keep, [ 'instock' => 1 ] ) : array_merge( $keep, [ 'instock' => '1' ] ) ), $stock_on ? 'true' : 'false' );
	$h       .= '</div>';

	$specs_on = array_intersect_key( $keep, array_flip( array_merge( [ 'min_price', 'max_price' ], array_map( fn( $k ) => "filter_$k", array_keys( FLC_FILTERS ) ) ) ) );
	if ( count( $ids ) > 1 ) {
		$in  = implode( ',', array_map( 'intval', $ids ) );
		$top = (float) $wpdb->get_var( "SELECT MAX(max_price) FROM {$wpdb->wc_product_meta_lookup} WHERE product_id IN ($in)" );
		$top = (int) ( ceil( $top / 5000 ) * 5000 );
		$min = min( $top, max( 0, (int) ( $keep['min_price'] ?? 0 ) ) );
		$max = min( $top, (int) ( $keep['max_price'] ?? $top ) ) ?: $top;

		$h .= '<details class="flc-refine"' . ( $specs_on ? ' open' : '' ) . '><summary>Filter by price, processor, RAM &amp; more' . ( $specs_on ? ' <em>' . count( $specs_on ) . '</em>' : '' ) . '</summary><div class="flc-refine__body">';
		$h .= '<form class="flc-price" method="get" action="' . esc_url( $base ) . '" data-flc-price>';
		foreach ( array_diff_key( $keep, array_flip( [ 'min_price', 'max_price' ] ) ) as $k => $v ) {
			$h .= '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '">';
		}
		$h .= sprintf(
			'<span class="flc-refine__label">Price</span><div class="flc-price__sliders"><input type="range" name="min_price" min="0" max="%1$d" step="1000" value="%2$d" aria-label="Lowest price"><input type="range" name="max_price" min="0" max="%1$d" step="1000" value="%3$d" aria-label="Highest price"></div><output>KSh %4$s – KSh %5$s</output><button class="flc-chip flc-chip--sm is-on" type="submit">Apply</button></form>',
			$top, $min, $max, number_format( $min ), number_format( $max )
		);
		foreach ( FLC_FILTERS as $key => $label ) {
			$terms = wp_get_object_terms( $ids, wc_attribute_taxonomy_name( $key ) );
			if ( is_wp_error( $terms ) || count( $terms ) < 2 ) {
				continue;
			}
			$param  = "filter_$key";
			$chosen = $keep[ $param ] ?? '';
			$h     .= '<div class="flc-filters__row"><span class="flc-refine__label">' . esc_html( $label ) . '</span>';
			foreach ( flc_term_sort( $key, $terms ) as $t ) {
				$on   = $chosen === $t->slug;
				$args = $on ? array_diff_key( $keep, [ $param => 1 ] ) : array_merge( $keep, [ $param => $t->slug ] );
				$h   .= sprintf( '<a class="flc-chip flc-chip--sm%s" href="%s" rel="nofollow">%s</a>', $on ? ' is-on' : '', $link( $args ), esc_html( $t->name ) );
			}
			$h .= '</div>';
		}
		$brands = taxonomy_exists( 'product_brand' ) ? wp_get_object_terms( $ids, 'product_brand', [ 'orderby' => 'count', 'order' => 'DESC' ] ) : [];
		if ( ! is_wp_error( $brands ) && count( $brands ) > 1 ) {
			$h .= '<div class="flc-filters__row"><span class="flc-refine__label">Brand</span>';
			foreach ( $brands as $t ) {
				$h .= sprintf( '<a class="flc-chip flc-chip--sm%s" href="%s">%s</a>', $t->term_id === $cur_id ? ' is-on' : '', esc_url( get_term_link( $t ) ), esc_html( $t->name ) );
			}
			$h .= '</div>';
		}
		$h .= '</div></details>';
	}
	if ( array_diff_key( $keep, array_flip( [ 'orderby', 's', 'post_type' ] ) ) ) {
		$h .= '<a class="flc-refine__clear" href="' . esc_url( add_query_arg( array_intersect_key( $keep, array_flip( [ 'orderby', 's', 'post_type' ] ) ), $base ) ) . '">✕ Clear filters</a>';
	}
	return $h . '</nav>';
} );

// "In stock only" switch on shop pages.
add_action( 'woocommerce_product_query', function ( $q ) {
	if ( ! empty( $_GET['instock'] ) ) {
		$meta   = (array) $q->get( 'meta_query' );
		$meta[] = [ 'key' => '_stock_status', 'value' => 'instock' ];
		$q->set( 'meta_query', $meta );
	}
} );
add_filter( 'query_loop_block_query_vars', function ( $vars ) {
	if ( ! empty( $_GET['instock'] ) && ( $vars['post_type'] ?? '' ) === 'product' ) {
		$vars['meta_query']   = (array) ( $vars['meta_query'] ?? [] );
		$vars['meta_query'][] = [ 'key' => '_stock_status', 'value' => 'instock' ];
	}
	return $vars;
} );

add_shortcode( 'flc_wishlist', function () {
	return '<div class="flc-wishlist" data-flc-wishlist><p class="flc-small">Loading your saved items…</p></div>';
} );

/* -------------------------------------------------------------------------
 * Wholesale page
 * ---------------------------------------------------------------------- */

// Bulk quote request: the form builds a WhatsApp message (flc.js), so nothing is stored here.
add_shortcode( 'flc_wholesale', function () {
	$opts = '';
	foreach ( WC()->countries->get_states( 'KE' ) ?: [] as $name ) {
		$opts .= '<option' . ( str_starts_with( $name, 'Nairobi' ) ? ' selected' : '' ) . '>' . esc_html( $name ) . '</option>';
	}
	ob_start();
	?>
	<div class="flc-ws">
		<div class="flc-ws__intro">
			<p class="flc-eyebrow">Electronics wholesaler · Nairobi CBD</p>
			<p class="flc-ws__lead">Kitting out an office, a school lab, a cyber café or your own shop? We supply laptops, desktops, all-in-ones, monitors, UPS units and accessories in bulk, with one invoice, one delivery and every machine tested.</p>
			<ul class="flc-ws__who">
				<li><strong>IT departments &amp; offices</strong>Matching EliteBooks, ProBooks or desktops for the whole team.</li>
				<li><strong>Schools &amp; colleges</strong>Lab desktops, Chromebooks and projectors.</li>
				<li><strong>Cyber cafés &amp; businesses</strong>Desktops, monitors, UPS units and POS terminals.</li>
				<li><strong>Resellers &amp; shops</strong>Trade prices on laptops, monitors and accessories for resale.</li>
			</ul>
			<ol class="flc-ws__steps">
				<li><span>1</span>Send your list: models (or a budget per machine), quantities and where it is going.</li>
				<li><span>2</span>We reply on WhatsApp with stock, a bulk price and any upgrades you need.</li>
				<li><span>3</span>Inspect and test at Moi Avenue, or we deliver: same day in Nairobi, courier upcountry.</li>
			</ol>
		</div>
		<form class="flc-ws__form" data-flc-wholesale>
			<h2>Request a bulk quote</h2>
			<label>Your name<input name="name" required autocomplete="name"></label>
			<label>Company, school or shop (optional)<input name="company" autocomplete="organization"></label>
			<label>Phone<input name="phone" type="tel" required autocomplete="tel" placeholder="07…"></label>
			<label>What do you need?<textarea name="items" rows="5" required placeholder="e.g. 10 × HP EliteBook 840 G6, Core i5, 16GB RAM&#10;10 × wireless mouse&#10;2 × APC 1kVA UPS"></textarea></label>
			<div class="flc-ws__row">
				<label>Delivery to<select name="county"><?php echo $opts; // phpcs:ignore -- escaped above. ?></select></label>
				<label>When<select name="when"><option>This week</option><option>Within 2 weeks</option><option>This month</option><option>Just pricing for now</option></select></label>
			</div>
			<button class="wp-element-button" type="submit"><?php echo FLC_WA_ICON; // phpcs:ignore ?> Send request on WhatsApp</button>
			<p class="flc-small">Opens WhatsApp with your request filled in, ready to send to <?php echo esc_html( FLC_PHONE ); ?>. Prefer to call? <a href="tel:+254796049477"><?php echo esc_html( FLC_PHONE ); ?></a> or <a href="tel:+254740949022"><?php echo esc_html( FLC_PHONE_2 ); ?></a>.</p>
		</form>
	</div>
	<?php
	return ob_get_clean() . '<h2 class="flc-ws__h">Popular for bulk orders</h2>' . do_shortcode( '[flc_collection cat="business-laptops" limit="5"]' ) . do_shortcode( '[flc_collection cat="desktop-pcs" limit="5"]' );
} );

/* -------------------------------------------------------------------------
 * Quick view, cart, checkout, order confirmation
 * ---------------------------------------------------------------------- */

// Quick view pop-up, filled in by flc.js.
add_action( 'wp_footer', function () {
	echo '<dialog id="flc-qv" class="flc-dialog flc-qv" aria-label="Quick view"><form method="dialog"><button class="flc-dialog__close" aria-label="Close">×</button></form><div data-flc-qv-body></div></dialog>';
} );

function flc_freebar_html() {
	$total = WC()->cart ? (float) WC()->cart->get_displayed_subtotal() : 0;
	$left  = max( 0, FLC_FREE_DELIVERY - $total );
	$pct   = min( 100, round( $total / FLC_FREE_DELIVERY * 100 ) );
	$msg   = $left > 0
		? 'Add <strong>' . flc_ksh( $left ) . '</strong> more for <strong>free Nairobi CBD express delivery!</strong>'
		: '<strong>You\'ve unlocked free Nairobi CBD express delivery!</strong>';
	return '<div class="flc-freebar" data-flc-freebar>' . $msg . '<div class="flc-freebar__track"><div class="flc-freebar__fill" style="width:' . $pct . '%"></div></div></div>';
}
function flc_wa_cart_html() {
	return '<button type="button" class="flc-wa-cart" data-flc-wa-cart>' . FLC_WA_ICON . 'Send this order to WhatsApp</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => flc_freebar_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . flc_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-filled-mini-cart-contents-block[^>]*>)#', '$1' . flc_freebar_html(), $c, 1 );
} );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="flc-wa-cart-wrap">' . flc_wa_cart_html() . '</div>' );

// A landmark helps riders find the customer.
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	woocommerce_register_additional_checkout_field( [
		'id'       => 'flc/landmark',
		'label'    => 'Building or nearest landmark',
		'location' => 'address',
		'type'     => 'text',
		'required' => false,
	] );
} );

// Tracking code, estimated delivery and WhatsApp receipt on the order confirmation page.
function flc_tracking_code( WC_Order $order ) {
	return 'FLC-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
function flc_eta( WC_Order $order ) {
	$method = strtolower( $order->get_shipping_method() );
	if ( str_contains( $method, 'pick' ) ) {
		return 'In-store pickup at Central Building, Moi Avenue. We\'ll call you when your order is ready to test and collect (' . FLC_HOURS . ').';
	}
	if ( str_contains( $method, 'upcountry' ) || str_contains( $method, 'courier' ) ) {
		return 'Upcountry courier: usually 1–2 days. We\'ll confirm the courier and send you the parcel details.';
	}
	return 'Nairobi express: same-day dispatch. We\'ll call you before the rider leaves.';
}
function flc_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Firelite Computers, I just placed order ' . flc_tracking_code( $order ) . ':' ];
	foreach ( $order->get_items() as $item ) {
		// The chosen configuration and any upgrades or add-ons.
		$extras  = array_map( fn( $m ) => html_entity_decode( wp_strip_all_tags( $m->display_key . ': ' . $m->display_value ), ENT_QUOTES ), $item->get_formatted_meta_data() );
		$lines[] = '• ' . $item->get_quantity() . ' × ' . $item->get_name() . ( $extras ? ' (' . implode( '; ', $extras ) . ')' : '' ) . ' – ' . flc_ksh( $item->get_total() );
	}
	$lines[] = 'Total: ' . flc_ksh( $order->get_total() );
	$lines[] = 'Delivery: ' . $order->get_shipping_method();
	$county  = WC()->countries->get_states( 'KE' )[ $order->get_shipping_state() ] ?? '';
	$address = trim( implode( ', ', array_filter( [ $order->get_shipping_address_1(), $order->get_shipping_city(), $county ] ) ) );
	if ( $address && ! $order->has_shipping_method( 'pickup_location' ) ) {
		$lines[] = 'Deliver to: ' . $address;
	}
	$lines[] = 'Payment: ' . $order->get_payment_method_title();
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return flc_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) {
		return $content;
	}
	return $content . '<div class="flc-thanks"><p class="flc-thanks__code">Order tracking number <strong>' . esc_html( flc_tracking_code( $order ) ) . '</strong></p><p class="flc-thanks__eta">' . esc_html( flc_eta( $order ) ) . '</p><p>We\'ll call you shortly to confirm. To speed things up, send the order summary to us on WhatsApp.</p><a class="wp-element-button flc-wa-btn" href="' . esc_attr( flc_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">' . FLC_WA_ICON . 'Send order summary to WhatsApp (+254 796 049 477)</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Tracking number:</strong> ' . esc_html( flc_tracking_code( $order ) ) . '</p>';
} );

// Newsletter: new stock and wholesale price lists. Staff see the list under WooCommerce → Subscribers.
add_action( 'admin_post_nopriv_flc_subscribe', 'flc_subscribe' );
add_action( 'admin_post_flc_subscribe', 'flc_subscribe' );
function flc_subscribe() {
	check_admin_referer( 'flc_subscribe' );
	$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$back  = wp_get_referer() ?: home_url( '/' );
	if ( ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( 'flc_sub', 'invalid', $back ) . '#newsletter' );
		exit;
	}
	$list = get_option( 'flc_subscribers', [] );
	$list[ strtolower( $email ) ] = current_time( 'mysql' );
	update_option( 'flc_subscribers', $list, false );
	wp_safe_redirect( add_query_arg( 'flc_sub', 'ok', $back ) . '#newsletter' );
	exit;
}

add_shortcode( 'flc_newsletter', function () {
	$state = sanitize_key( $_GET['flc_sub'] ?? '' );
	if ( $state === 'ok' ) {
		return '<p class="flc-news-ok"><strong>You\'re on the list!</strong> New tech drops and our wholesale price lists will land in your inbox.</p>';
	}
	$err = $state === 'invalid' ? '<p class="flc-news-err">Please enter a valid email address.</p>' : '';
	return '<form class="flc-news-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
		. '<input type="hidden" name="action" value="flc_subscribe">'
		. wp_nonce_field( 'flc_subscribe', '_wpnonce', true, false )
		. '<input type="email" name="email" required placeholder="Your email address" aria-label="Email address">'
		. '<button class="wp-element-button" type="submit">Subscribe</button>'
		. '</form>' . $err;
} );

add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Newsletter subscribers', 'Subscribers', 'manage_woocommerce', 'flc-subscribers', function () {
		$list = get_option( 'flc_subscribers', [] );
		echo '<div class="wrap"><h1>Newsletter subscribers (' . count( $list ) . ')</h1><table class="widefat striped"><thead><tr><th>Email</th><th>Signed up</th></tr></thead><tbody>';
		foreach ( array_reverse( $list, true ) as $email => $when ) {
			echo '<tr><td>' . esc_html( $email ) . '</td><td>' . esc_html( $when ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	} );
} );

// Staff edit the card badge, specs, condition and upgrade options on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_flc_spec', 'label' => 'Card badge', 'description' => 'Short label on the product card, e.g. "Core i5 8th Gen · 8GB · 256GB SSD".', 'desc_tip' => true ] );
	woocommerce_wp_textarea_input( [ 'id' => '_flc_specs', 'label' => 'Specifications', 'rows' => 7, 'description' => 'One per line, as "Label: value", e.g. "Processor: Intel Core i5, 8th Gen". The first four also show next to the price.' ] );
	woocommerce_wp_select( [ 'id' => '_flc_kind', 'label' => 'Product type', 'description' => 'Laptops get both add-ons, desktops get software setup.', 'desc_tip' => true, 'options' => [ 'laptop' => 'Laptop', 'desktop' => 'Desktop / all-in-one / POS', 'monitor' => 'Monitor', 'ups' => 'UPS', 'printer' => 'Printer', 'acc' => 'Accessory' ] ] );
	woocommerce_wp_select( [ 'id' => '_flc_cond', 'label' => 'Condition tag', 'options' => [ '' => '— None —', 'exuk' => 'Ex-UK', 'new' => 'Brand new / boxed', 'mixed' => 'Ex-UK & boxed (options)' ] ] );
	woocommerce_wp_text_input( [ 'id' => '_flc_ram_steps', 'label' => 'RAM upgrades (GB)', 'placeholder' => 'e.g. 8,16,32', 'description' => 'Sizes offered, starting with what it ships with. Leave empty if the RAM is soldered. Sizes: 4, 8, 16, 24, 32.', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_flc_ssd_steps', 'label' => 'SSD upgrades (GB)', 'placeholder' => 'e.g. 256,512,1024', 'description' => 'Sizes offered, starting with what it ships with. Sizes: 256, 512, 1024.', 'desc_tip' => true ] );
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_flc_spec' => 'sanitize_text_field', '_flc_specs' => 'sanitize_textarea_field', '_flc_kind' => 'sanitize_key', '_flc_cond' => 'sanitize_key' ] as $key => $clean ) {
		if ( isset( $_POST[ $key ] ) ) {
			$product->update_meta_data( $key, $clean( wp_unslash( $_POST[ $key ] ) ) );
		}
	}
	foreach ( [ '_flc_ram_steps', '_flc_ssd_steps' ] as $key ) {
		if ( isset( $_POST[ $key ] ) ) {
			$product->update_meta_data( $key, implode( ',', array_filter( array_map( 'intval', explode( ',', wp_unslash( $_POST[ $key ] ) ) ) ) ) );
		}
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode, and riders need a phone number.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['city']     = [ 'label' => 'Area / Estate / Town (e.g. CBD, Westlands, Nakuru)' ];
	$locale['KE']['state']    = [ 'label' => 'County' ];
	$locale['KE']['phone']    = [ 'required' => true ];
	return $locale;
} );

// Demo stores ship web-sized photos and skip thumbnails (see setup.php).
if ( get_option( 'flc_fast_images' ) === 'yes' ) {
	add_filter( 'woocommerce_resize_images', '__return_false' );
	add_filter( 'woocommerce_background_image_regeneration', '__return_false' );
}

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#1A1A1A\">\n";
} );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src)="/(?!/)#', '$1="' . $home, $content );
} );

// The shop shows no WordPress toolbar, version tags or discovery links. Staff work from /wp-admin.
add_filter( 'show_admin_bar', '__return_false' );
add_filter( 'the_generator', '__return_empty_string' );
add_filter( 'xmlrpc_enabled', '__return_false' );
add_filter( 'emoji_svg_url', '__return_false' );
add_filter( 'wp_headers', function ( $headers ) {
	unset( $headers['X-Pingback'] );
	return $headers;
} );
add_action( 'init', function () {
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'rest_output_link_wp_head' );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'wp_head', 'feed_links', 2 );
	remove_action( 'wp_head', 'feed_links_extra', 3 );
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_footer_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
	remove_action( 'template_redirect', 'rest_output_link_header', 11 );
	remove_action( 'template_redirect', 'wp_shortlink_header', 11 );
} );

// The staff login page carries the shop's mark instead of the WordPress one.
add_action( 'login_enqueue_scripts', function () {
	$logo = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<style>body.login{background:#1A1A1A}body.login #login h1 a{background:url($logo) center/contain no-repeat;width:96px;height:96px;border-radius:22px}body.login #nav a{color:#E5E5E5}#backtoblog,.language-switcher{display:none}.wp-core-ui .button-primary{background:#E0006C;border-color:#E0006C}</style>";
} );
add_filter( 'login_title', fn( $title ) => str_replace( [ ' &#8212; WordPress', ' — WordPress' ], '', $title ) );
add_filter( 'login_headerurl', fn() => home_url( '/' ) );
add_filter( 'login_headertext', fn() => 'Firelite Computers' );
